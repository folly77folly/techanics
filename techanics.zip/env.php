<?php
// MAIL_SMTP = smtp.gmail.com
$_ENV['MAIL_TO']="iamaqim@gmail.com";