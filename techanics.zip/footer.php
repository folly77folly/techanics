  <footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <!--<div class="col-lg-3 col-md-6 footer-info">
            <h3>Techanics</h3>
            <p>Cras fermentum odio eu feugiat lide par naso tierra. Justo eget nada terra videa magna derita valies darta donna mare fermentum iaculis eu non diam phasellus.</p>
          </div>-->
          <div class="col-lg-4 col-md-6 footer-contact">
            <h4>Contact Us</h4>
            <p>
              Indira Shankar Nagari, Bhusari Colony,<br>
              Kothrud, Pune, Maharashtra 411038<br>
              <br>
              F 146, Sector 5, DSIIDC,<br>
              Bawana, New Delhi 110039<br>
              <br>
              <strong>Phone:</strong> 8882655840<br>
              <strong>Email:</strong> support@hspmsolutions.com<br>
            </p>

            <div class="social-links mt-2">
              <a href="#" class="twitter"><i class="icofont-twitter"></i></a>
              <a href="#" class="facebook"><i class="icofont-facebook"></i></a>
              <a href="#" class="instagram"><i class="icofont-instagram"></i></a>
              <a href="#" class="linkedin"><i class="icofont-linkedin"></i></a>
            </div>

          </div>
          
          <div class="col-lg-5 col-md-6 footer-newsletter text-center my-auto">
              <a href="https://www.hspmsolutions.com/"><img src = "assets/img/mainlogo.jpeg" class="img-fluid"></a> 
          </div>
          
          <div class="col-lg-3 col-md-6 footer-links">
              <h4>Useful Links</h4>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About us</a></li>
                <li><a href="blog.php">Blog</a></li>
                <li><a href="faq.php">FAQ</a></li>
                <li><a href="work.php">Work with Us</a></li>
                <li><a href="contact.php">Contact Us</a></li>
                <li><a href="privacy.php">Privacy policy</a></li>
            </ul>
          </div>

        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright. All Rights Reserved
      </div>
      <div class="credits">
        Designed by <a href="https://www.hspmsolutions.com/">HSPM sol ltd</a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
  <script src="assets/vendor/counterup/counterup.min.js"></script>
  <script src="assets/vendor/venobox/venobox.min.js"></script>
  <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>