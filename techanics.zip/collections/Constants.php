<?php
namespace App\Collections;

Class Constants {
    public static $LIMIT = 50;
    public static $ZERO = 0;
    public static $BUY = "buy";
    public static $SELL = "sell";
}