<?php
    require 'header_top.php';
?>
<style>
    .limiter{
        min-height: 80vh;
        padding-top: 80px;
    }
    .table100 td{
        text-align: center;
    }
    .table100 th{
        text-align: center;
    }
</style>
	<div class="limiter">
		<div class="container-table100">
			<div class="wrap-table100">
				<div class="table100">
					<table>
						<thead>
							<tr class="table100-head">
								<th class="column1">Order Id</th>
								<th class="column2">Image</th>
								<th class="column3">Name</th>
								<th class="column4">Price</th>
								<th class="column5">Date</th>
								<th class="column6">Actions</th>
								<th class="column7">Bill</th>
							</tr>
						</thead>
						<tbody>
								<tr>
									<td class="column1">XXXXXX</td>
									<td class="column22"> <img src="assets/img/slide/1.png" class="img-fluid mt-2 mb-2 mx-auto" style="
										width: 100px"></td>
									<td class="column3">iPhone X 64Gb Grey</td>
									<td class="column4">$999.00</td>
									<td class="column5">2017-09-29</td>
									<td class="column6"> <button class="btn themebtn" type="button">Review</button>
										<button class="btn themebtn" type="button">Buy again</button>
                                                                                <button class="btn themebtn" type="button">Track</button></td> 
									<td class="column7"><a href="#" class='btn themebtn'>Invoice</a></td>
								</tr>
								<tr>
									<td class="column1">XXXXXX</td>
									<td class="column22"> <img src="assets/img/slide/1.png" class="img-fluid mt-2 mb-2 mx-auto" style="
										width: 100px"></td>
									<td class="column3">iPhone X 64Gb Grey</td>
									<td class="column4">$999.00</td>
									<td class="column5">2017-09-29</td>
									<td class="column6"> <button class="btn themebtn" type="button">Review</button>
										<button class="btn themebtn" type="button">Buy again</button>
                                                                                <button class="btn themebtn" type="button">Track</button></td> 
									<td class="column7"><a href="#" class='btn themebtn'>Invoice</a></td>
								</tr>
								<tr>
									<td class="column1">XXXXXX</td>
									<td class="column22"> <img src="assets/img/slide/1.png" class="img-fluid mt-2 mb-2 mx-auto" style="
										width: 100px"></td>
									<td class="column3">iPhone X 64Gb Grey</td>
									<td class="column4">$999.00</td>
									<td class="column5">2017-09-29</td>
									<td class="column6"> <button class="btn themebtn" type="button">Review</button>
										<button class="btn themebtn" type="button">Buy again</button>
                                                                                <button class="btn themebtn" type="button">Track</button></td> 
									<td class="column7"><a href="#" class='btn themebtn'>Invoice</a></td>
								</tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>

<?php
    require 'footer.php';
?>